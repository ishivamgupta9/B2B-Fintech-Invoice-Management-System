package highradius_project.servlet;

public class TotalRows {

}
